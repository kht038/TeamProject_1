﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActorInfo
{
    //public int m_PlayerHP;
    //public int m_MaxPlayerHP;
    //public int m_ExtraPlayerHP;
    //public void Intialize(int Hp)
    //{
    //    m_ExtraPlayerHP = CalculateAddHP();
    //    m_MaxPlayerHP = Hp;
    //    m_PlayerHP = m_MaxPlayerHP + m_ExtraPlayerHP;
    //}
    //
    //public void AddDamage(int damage)
    //{
    //    m_PlayerHP -= damage;
    //
    //    if(m_PlayerHP <= 0)
    //    {
    //       m_PlayerHP = 0;
    //    }
    //}
    //
    //public bool IsDie()
    //{
    //    return m_PlayerHP == 0;
    //}
    //
    //public int CalculateAddHP()
    //{
    //    SaveInfo kSaveInfo = GameMgr.Inst.m_saveInfo;
    //    return (int)(kSaveInfo.m_AccumulateScore * 0.001f * Config.DMIN_ADD_HP);
    //}
    //public int CalculateMaxHP()
    //{
    //    return m_MaxPlayerHP + m_ExtraPlayerHP;
    //}
}
